import React, { useState, useEffect } from 'react';
import './App.css';
import { 
  Navbar, 
  HeroSection, 
  ContentRow, 
  TrailerModal, 
  LoadingSpinner 
} from './components';

function App() {
  const [content, setContent] = useState({
    trending: [],
    topRated: [],
    nowPlaying: [],
    popular: [],
    tvShows: []
  });
  const [featuredContent, setFeaturedContent] = useState(null);
  const [selectedContent, setSelectedContent] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  
  // Mock user profiles
  const [profiles] = useState([
    {
      id: 1,
      name: 'John',
      avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d'
    },
    {
      id: 2,
      name: 'Sarah',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330'
    },
    {
      id: 3,
      name: 'Mike',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde'
    }
  ]);
  const [activeProfile, setActiveProfile] = useState(profiles[0]);
  
  // API configuration
  const API_KEY = 'c8dea14dc917687ac631a52620e4f7ad';
  const BASE_URL = 'https://api.themoviedb.org/3';
  
  useEffect(() => {
    fetchAllContent();
  }, []);
  
  const fetchAllContent = async () => {
    try {
      setLoading(true);
      
      const endpoints = [
        `${BASE_URL}/trending/all/day?api_key=${API_KEY}`,
        `${BASE_URL}/movie/top_rated?api_key=${API_KEY}`,
        `${BASE_URL}/movie/now_playing?api_key=${API_KEY}`,
        `${BASE_URL}/movie/popular?api_key=${API_KEY}`,
        `${BASE_URL}/tv/popular?api_key=${API_KEY}`
      ];
      
      const responses = await Promise.all(
        endpoints.map(url => fetch(url).then(res => res.json()))
      );
      
      const [trending, topRated, nowPlaying, popular, tvShows] = responses;
      
      // Enhanced content processing to ensure better image handling
      const processContent = (contentArray) => {
        return contentArray.map(item => ({
          ...item,
          // Ensure we have fallback images if poster_path is missing
          poster_path: item.poster_path || item.backdrop_path,
          backdrop_path: item.backdrop_path || item.poster_path,
          // Add additional metadata
          vote_average: item.vote_average || 0,
          overview: item.overview || 'A captivating story that will keep you entertained.',
          // Ensure consistent naming
          display_title: item.title || item.name || 'Untitled',
          display_date: item.release_date || item.first_air_date || '2024'
        }));
      };
      
      setContent({
        trending: processContent(trending.results || []),
        topRated: processContent(topRated.results || []),
        nowPlaying: processContent(nowPlaying.results || []),
        popular: processContent(popular.results || []),
        tvShows: processContent(tvShows.results || [])
      });
      
      // Set featured content from trending with enhanced data
      if (trending.results && trending.results.length > 0) {
        const featured = trending.results[0];
        setFeaturedContent({
          ...featured,
          poster_path: featured.poster_path || featured.backdrop_path,
          backdrop_path: featured.backdrop_path || featured.poster_path,
          overview: featured.overview || 'A captivating story that will keep you on the edge of your seat.',
          vote_average: featured.vote_average || 8.5
        });
      }
      
    } catch (error) {
      console.error('Error fetching content:', error);
      // Enhanced fallback to mock data with better image handling
      setMockContent();
    } finally {
      setLoading(false);
    }
  };
  
  const setMockContent = () => {
    const mockData = {
      trending: [
        {
          id: 1,
          title: 'Stranger Things',
          overview: 'When a young boy vanishes, a small town uncovers a mystery involving secret experiments.',
          backdrop_path: null,
          poster_path: null,
          release_date: '2016-07-15'
        },
        {
          id: 2,
          title: 'The Crown',
          overview: 'Follows the political rivalries and romance of Queen Elizabeth II\'s reign.',
          backdrop_path: null,
          poster_path: null,
          release_date: '2016-11-04'
        },
        {
          id: 3,
          title: 'Ozark',
          overview: 'A financial advisor drags his family from Chicago to the Missouri Ozarks.',
          backdrop_path: null,
          poster_path: null,
          release_date: '2017-07-21'
        }
      ],
      topRated: [
        {
          id: 4,
          title: 'Breaking Bad',
          overview: 'A high school chemistry teacher turned methamphetamine producer.',
          backdrop_path: null,
          poster_path: null,
          release_date: '2008-01-20'
        }
      ],
      nowPlaying: [
        {
          id: 5,
          title: 'Better Call Saul',
          overview: 'The trials and tribulations of criminal lawyer Jimmy McGill.',
          backdrop_path: null,
          poster_path: null,
          release_date: '2015-02-08'
        }
      ],
      popular: [
        {
          id: 6,
          title: 'Money Heist',
          overview: 'A criminal mastermind manipulates the police to carry out a perfect robbery.',
          backdrop_path: null,
          poster_path: null,
          release_date: '2017-05-02'
        }
      ],
      tvShows: [
        {
          id: 7,
          name: 'Wednesday',
          overview: 'Wednesday Addams navigates her years as a student at Nevermore Academy.',
          backdrop_path: null,
          poster_path: null,
          first_air_date: '2022-11-23'
        }
      ]
    };
    
    setContent(mockData);
    setFeaturedContent(mockData.trending[0]);
  };
  
  const handlePlayTrailer = (contentItem) => {
    setSelectedContent(contentItem);
    setIsModalOpen(true);
  };
  
  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedContent(null);
  };
  
  if (loading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="App bg-black min-h-screen">
      <Navbar 
        activeProfile={activeProfile}
        setActiveProfile={setActiveProfile}
        profiles={profiles}
      />
      
      <HeroSection 
        featuredContent={featuredContent}
        onPlayTrailer={handlePlayTrailer}
      />
      
      <div className="pb-20">
        {content.trending.length > 0 && (
          <ContentRow 
            title="Trending Now"
            content={content.trending}
            onPlayTrailer={handlePlayTrailer}
          />
        )}
        
        {content.topRated.length > 0 && (
          <ContentRow 
            title="Top Rated Movies"
            content={content.topRated}
            onPlayTrailer={handlePlayTrailer}
          />
        )}
        
        {content.nowPlaying.length > 0 && (
          <ContentRow 
            title="Now Playing"
            content={content.nowPlaying}
            onPlayTrailer={handlePlayTrailer}
          />
        )}
        
        {content.popular.length > 0 && (
          <ContentRow 
            title="Popular Movies"
            content={content.popular}
            onPlayTrailer={handlePlayTrailer}
          />
        )}
        
        {content.tvShows.length > 0 && (
          <ContentRow 
            title="Popular TV Shows"
            content={content.tvShows}
            onPlayTrailer={handlePlayTrailer}
          />
        )}
      </div>
      
      <TrailerModal 
        content={selectedContent}
        isOpen={isModalOpen}
        onClose={closeModal}
      />
    </div>
  );
}

export default App;