import React, { useState, useEffect, useRef } from 'react';

// Netflix Logo Component
export const NetflixLogo = () => (
  <div className="flex items-center">
    <img 
      src="https://images.unsplash.com/photo-1611162617474-5b21e879e113" 
      alt="Netflix" 
      className="h-8 w-8 mr-2"
    />
    <span className="text-red-600 font-bold text-xl">NETFLIX</span>
  </div>
);

// Navigation Bar Component
export const Navbar = ({ activeProfile, setActiveProfile, profiles }) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  
  return (
    <nav className="fixed top-0 w-full z-50 bg-black bg-opacity-90 backdrop-blur-sm">
      <div className="px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <NetflixLogo />
          <ul className="hidden md:flex space-x-6">
            <li><a href="#" className="text-white hover:text-gray-300 transition-colors">Home</a></li>
            <li><a href="#" className="text-white hover:text-gray-300 transition-colors">TV Shows</a></li>
            <li><a href="#" className="text-white hover:text-gray-300 transition-colors">Movies</a></li>
            <li><a href="#" className="text-white hover:text-gray-300 transition-colors">New & Popular</a></li>
            <li><a href="#" className="text-white hover:text-gray-300 transition-colors">My List</a></li>
          </ul>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="text-white hover:text-gray-300">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </button>
          
          <div className="relative">
            <button 
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="flex items-center space-x-2"
            >
              <img 
                src={activeProfile.avatar} 
                alt={activeProfile.name}
                className="w-8 h-8 rounded"
              />
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            
            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-black bg-opacity-90 rounded-md shadow-lg py-2">
                {profiles.map((profile) => (
                  <button
                    key={profile.id}
                    onClick={() => {
                      setActiveProfile(profile);
                      setShowProfileMenu(false);
                    }}
                    className="flex items-center space-x-3 px-4 py-2 text-white hover:bg-gray-800 w-full text-left"
                  >
                    <img src={profile.avatar} alt={profile.name} className="w-6 h-6 rounded" />
                    <span>{profile.name}</span>
                  </button>
                ))}
                <hr className="border-gray-600 my-2" />
                <button className="px-4 py-2 text-white hover:bg-gray-800 w-full text-left">
                  Manage Profiles
                </button>
                <button className="px-4 py-2 text-white hover:bg-gray-800 w-full text-left">
                  Sign out of Netflix
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

// Hero Section Component
export const HeroSection = ({ featuredContent, onPlayTrailer }) => {
  const [backgroundLoaded, setBackgroundLoaded] = useState(false);
  
  if (!featuredContent) return null;
  
  // Get high-quality background image with fallbacks
  const getBackgroundImage = (content) => {
    const fallbackBackgrounds = [
      'https://images.pexels.com/photos/21802645/pexels-photo-21802645.jpeg', // Starry night
      'https://images.unsplash.com/photo-1562327699-e48794711fe9', // Dark cinematic
      'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb', // Batman style
      'https://images.unsplash.com/photo-1590179068383-b9c69aacebd3' // Classic cinema
    ];
    
    if (content.backdrop_path) {
      return `https://image.tmdb.org/t/p/original${content.backdrop_path}`;
    }
    
    // Use poster as backdrop if no backdrop available
    if (content.poster_path) {
      return `https://image.tmdb.org/t/p/original${content.poster_path}`;
    }
    
    // Genre-based fallback
    const fallbackIndex = content.id ? content.id % fallbackBackgrounds.length : 0;
    return fallbackBackgrounds[fallbackIndex];
  };
  
  const backgroundImage = getBackgroundImage(featuredContent);
  
  return (
    <div className="relative h-screen">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.7)), url(${backgroundImage})`,
          opacity: backgroundLoaded ? 1 : 0
        }}
      />
      
      {/* Preload background image */}
      <img 
        src={backgroundImage}
        alt=""
        className="hidden"
        onLoad={() => setBackgroundLoaded(true)}
        onError={() => setBackgroundLoaded(true)}
      />
      
      {/* Loading state for hero */}
      {!backgroundLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-600 mx-auto mb-4"></div>
            <p className="text-white text-xl">Loading Featured Content...</p>
          </div>
        </div>
      )}
      
      <div className="relative z-10 flex items-center h-full px-6 md:px-12">
        <div className="max-w-2xl text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight animate-fade-in">
            {featuredContent.title || featuredContent.name}
          </h1>
          
          <p className="text-lg md:text-xl mb-6 leading-relaxed animate-slide-up">
            {featuredContent.overview || 'A captivating story that will keep you on the edge of your seat.'}
          </p>
          
          {/* Movie details */}
          <div className="flex items-center space-x-4 mb-6 text-sm text-gray-300">
            {featuredContent.vote_average && (
              <div className="flex items-center">
                <svg className="w-4 h-4 text-yellow-400 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <span>{featuredContent.vote_average.toFixed(1)}</span>
              </div>
            )}
            {(featuredContent.release_date || featuredContent.first_air_date) && (
              <span>
                {new Date(featuredContent.release_date || featuredContent.first_air_date).getFullYear()}
              </span>
            )}
            {featuredContent.adult === false && (
              <span className="bg-gray-600 px-2 py-1 rounded text-xs">PG-13</span>
            )}
          </div>
          
          <div className="flex space-x-4">
            <button 
              onClick={() => onPlayTrailer(featuredContent)}
              className="flex items-center bg-white text-black px-8 py-3 rounded font-semibold hover:bg-gray-200 transition-colors"
            >
              <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z"/>
              </svg>
              Play
            </button>
            
            <button className="flex items-center bg-gray-500 bg-opacity-70 text-white px-8 py-3 rounded font-semibold hover:bg-opacity-50 transition-colors">
              <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              More Info
            </button>
          </div>
        </div>
      </div>
      
      {/* Fade effect at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
    </div>
  );
};

// Movie/Show Card Component
export const ContentCard = ({ content, onPlayTrailer, onHover, onLeave }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  // High-quality image URLs with multiple fallbacks
  const getImageUrls = (content) => {
    const fallbackPosters = [
      'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHwxfHxtb3ZpZSUyMHBvc3RlcnxlbnwwfHx8YmxhY2t8MTc1MDU4NzE0OXww&ixlib=rb-4.1.0&q=85', // Batman action poster
      'https://images.unsplash.com/photo-1590179068383-b9c69aacebd3?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHwyfHxtb3ZpZSUyMHBvc3RlcnxlbnwwfHx8YmxhY2t8MTc1MDU4NzE0OXww&ixlib=rb-4.1.0&q=85', // Classic cinema poster
      'https://images.unsplash.com/photo-1641549058491-8a3442385da0?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2MzR8MHwxfHNlYXJjaHwzfHxtb3ZpZSUyMHBvc3RlcnxlbnwwfHx8YmxhY2t8MTc1MDU4NzE0OXww&ixlib=rb-4.1.0&q=85', // Pulp Fiction style
      'https://images.unsplash.com/photo-1715305278832-4e4a15d1a083?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzF8MHwxfHNlYXJjaHwxfHxjaW5lbWElMjBwb3N0ZXJ8ZW58MHx8fGJsYWNrfDE3NTA2MTMxMTl8MA&ixlib=rb-4.1.0&q=85', // Vintage poster
      'https://images.unsplash.com/photo-1623841305968-f85336594764?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzF8MHwxfHNlYXJjaHwyfHxjaW5lbWElMjBwb3N0ZXJ8ZW58MHx8fGJsYWNrfDE3NTA2MTMxMTl8MA&ixlib=rb-4.1.0&q=85', // Theater display
      'https://images.unsplash.com/photo-1521678164864-532dfc45a5b9?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzF8MHwxfHNlYXJjaHwzfHxjaW5lbWElMjBwb3N0ZXJ8ZW58MHx8fGJsYWNrfDE3NTA2MTMxMTl8MA&ixlib=rb-4.1.0&q=85'  // Cinema facade
    ];
    
    const urls = [];
    
    // Primary: High-quality TMDB poster
    if (content.poster_path) {
      urls.push(`https://image.tmdb.org/t/p/w780${content.poster_path}`);
      urls.push(`https://image.tmdb.org/t/p/w500${content.poster_path}`);
    }
    
    // Secondary: TMDB backdrop as fallback
    if (content.backdrop_path) {
      urls.push(`https://image.tmdb.org/t/p/w780${content.backdrop_path}`);
    }
    
    // Tertiary: Genre-specific fallback based on content ID
    const fallbackIndex = content.id % fallbackPosters.length;
    urls.push(fallbackPosters[fallbackIndex]);
    
    // Final fallback: Different poster
    urls.push(fallbackPosters[(fallbackIndex + 1) % fallbackPosters.length]);
    
    return urls;
  };
  
  const imageUrls = getImageUrls(content);
  const currentImageUrl = imageUrls[currentImageIndex];
  
  const handleImageError = () => {
    if (currentImageIndex < imageUrls.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1);
    } else {
      setImageLoaded(true); // Stop trying after all fallbacks
    }
  };
  
  return (
    <div 
      className="relative flex-shrink-0 w-64 cursor-pointer transform transition-transform duration-300 hover:scale-105 hover:z-10"
      onMouseEnter={() => onHover(content)}
      onMouseLeave={onLeave}
    >
      <div className="relative">
        <img 
          key={`${content.id}-${currentImageIndex}`}
          src={currentImageUrl}
          alt={content.title || content.name}
          className={`w-full h-36 object-cover rounded-lg transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => setImageLoaded(true)}
          onError={handleImageError}
        />
        
        {!imageLoaded && (
          <div className="w-full h-36 bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mx-auto mb-2"></div>
              <div className="text-gray-400 text-xs">Loading...</div>
            </div>
          </div>
        )}
        
        <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-50 transition-all duration-300 rounded-lg flex items-center justify-center opacity-0 hover:opacity-100">
          <button 
            onClick={() => onPlayTrailer(content)}
            className="bg-white bg-opacity-90 text-black p-3 rounded-full hover:bg-opacity-100 transition-all transform scale-90 hover:scale-100"
          >
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </button>
        </div>
        
        {/* Quality indicator */}
        <div className="absolute top-2 right-2 opacity-0 hover:opacity-100 transition-opacity">
          <div className="bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
            HD
          </div>
        </div>
      </div>
      
      <div className="mt-2">
        <h3 className="text-white text-sm font-medium truncate">
          {content.title || content.name}
        </h3>
        <p className="text-gray-400 text-xs">
          {content.release_date || content.first_air_date 
            ? new Date(content.release_date || content.first_air_date).getFullYear()
            : 'Unknown'}
        </p>
      </div>
    </div>
  );
};

// Content Row Component
export const ContentRow = ({ title, content, onPlayTrailer }) => {
  const scrollContainerRef = useRef(null);
  const [hoveredContent, setHoveredContent] = useState(null);
  
  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = 1000;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };
  
  return (
    <div className="mb-8">
      <h2 className="text-white text-xl font-semibold mb-4 px-6">{title}</h2>
      
      <div className="relative group">
        <button 
          onClick={() => scroll('left')}
          className="absolute left-2 top-1/2 transform -translate-y-1/2 z-20 bg-black bg-opacity-50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-opacity-70"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        
        <div 
          ref={scrollContainerRef}
          className="flex space-x-4 overflow-x-auto scrollbar-hide px-6 pb-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {content.map((item) => (
            <ContentCard 
              key={item.id}
              content={item}
              onPlayTrailer={onPlayTrailer}
              onHover={setHoveredContent}
              onLeave={() => setHoveredContent(null)}
            />
          ))}
        </div>
        
        <button 
          onClick={() => scroll('right')}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 z-20 bg-black bg-opacity-50 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-opacity-70"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
};

// YouTube Trailer Modal Component
export const TrailerModal = ({ content, isOpen, onClose }) => {
  const [trailerKey, setTrailerKey] = useState(null);
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    if (isOpen && content) {
      fetchTrailer();
    }
  }, [isOpen, content]);
  
  const fetchTrailer = async () => {
    setLoading(true);
    try {
      const API_KEY = 'c8dea14dc917687ac631a52620e4f7ad';
      const mediaType = content.title ? 'movie' : 'tv';
      const response = await fetch(
        `https://api.themoviedb.org/3/${mediaType}/${content.id}/videos?api_key=${API_KEY}`
      );
      const data = await response.json();
      
      const trailer = data.results?.find(video => 
        video.type === 'Trailer' && video.site === 'YouTube'
      );
      
      if (trailer) {
        setTrailerKey(trailer.key);
      } else {
        // Fallback to any YouTube video
        const youtubeVideo = data.results?.find(video => video.site === 'YouTube');
        setTrailerKey(youtubeVideo?.key || 'dQw4w9WgXcQ'); // Rick Roll as ultimate fallback
      }
    } catch (error) {
      console.error('Error fetching trailer:', error);
      setTrailerKey('dQw4w9WgXcQ'); // Fallback
    }
    setLoading(false);
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="relative w-full max-w-4xl mx-4">
        <button 
          onClick={onClose}
          className="absolute -top-12 right-0 text-white hover:text-gray-300 z-10"
        >
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        
        <div className="bg-black rounded-lg overflow-hidden">
          <div className="relative w-full h-0 pb-56.25">
            {loading ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-white">Loading trailer...</div>
              </div>
            ) : trailerKey ? (
              <iframe
                className="absolute inset-0 w-full h-full"
                src={`https://www.youtube.com/embed/${trailerKey}?autoplay=1&rel=0`}
                title="Movie Trailer"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-white">
                Trailer not available
              </div>
            )}
          </div>
          
          <div className="p-6">
            <h3 className="text-white text-2xl font-bold mb-2">
              {content?.title || content?.name}
            </h3>
            <p className="text-gray-300 text-sm">
              {content?.overview}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Loading Component
export const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-screen bg-black">
    <div className="text-center">
      <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-red-600 mx-auto mb-4"></div>
      <p className="text-white text-xl">Loading Netflix...</p>
    </div>
  </div>
);